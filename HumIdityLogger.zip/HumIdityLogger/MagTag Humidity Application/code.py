# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

import time
import array
import board
import neopixel
import displayio
import terminalio
import adafruit_sht4x

from adafruit_display_text import label
from adafruit_display_shapes.line import Line
from adafruit_display_shapes.rect import Rect
#from adafruit_display_shapes.roundrect import RoundRect

from adafruit_magtag.magtag import MagTag

tempbuffer = array.array('f', [0.0] * 300)      # Temperature values as reported by the sensor
scale_temp = array.array('f', [0.0] * 300)      # Temperature values scaled to graph points
humbuffer = array.array('f', [0.0] * 300)       # Same but for humidity
scale_hum = array.array('f', [0.0] * 300)

#### BEGIN ### BEGIN ###  BEGIN User-Settable Constants Section  ### BEGIN ### BEGIN ### BEGIN ###

# Don't change anything outside the BEGIN/END User Settable Constants section
# unless you know what you are doing. If you break the code, just grab a new copy
# from the archive and copy it onto the MagTag USB drive.

DrawTemp = True         # Default starting graph configuration. If you want the display
Celsius = True          # to wake up without the temperature graph, set DrawTemp = False.
DrawLabels = True       # Want Fahrenheit instead? Set Celsius = False.
ButtonSound = True      # Audible feedback from button presses - upsets our dog

UseMax = True           # Use the max RH found during a sample period instead of the average at the end
                        # Using the max to draw the graph is more likely to show door openings
                        # at the expense of a small offset from the noise when there aren't peaks.
                        # False will likely miss short deviations but won't add the offset from noise.

# Values aren't range checked so be careful when changing them.

Alarm = False           # False is default stock but can easily be toggled on
AlarmLevel = 20.0       # While relative humidity is greater than or equal to the AlarmLevel, and Alarm
                        # is True, it will sound an alarm tone.

HoursToDisplay = 48     # Set hours of data to display on the X (time) axis. 48 hours is default
                        # Don't go below 2 hours for testing and 24 hours for routine use
                        # Below 2 hours for testing and the screen is refreshing too rapidly.
                        # Below 24 hours may impact display lifetime over long term use.
                        # The display is 294 points so 294 hours is one graph point per hour for a
                        # 12 day display.

#################################  LED Levels #########################################

# 6 LED levels but 5 are tested, 6 is a default. RH% levels to compare to.
# Anything less than RHL1 is grn, grn, grn, grn

RHL1 = 15    # RH above this value and lights go to yel, grn, grn, grn
RHL2 = 20    # RH above this value and lights go to red, yel, grn, grn
RHL3 = 25    # RH above this value and lights go to red, red, yel, grn
RHL4 = 30    # RH above this value and lights go to red, red, red, yel
RHL5 = 35    # RH above this value and lights go to red, red, red, red

#############################  Neopixel Stuff  #######################################

DARK = (0, 0, 0)    # pixel values are R, G, B on 0-255 scale - can tune colors here
RED = (255, 0, 0)
YELLOW = (190, 140, 0)
GREEN = (0, 255, 0)
CYAN = (0, 125, 255)
BLUE = (0, 0, 255)
PURPLE = (125, 0, 255)
WHITE = (255, 255, 255)

### END ### END ### END ##  END User-Settable Constants Section #### END ### END ### END ###

# Don't change anything outside the BEGIN/END User Settable Constants section
# unless you know what you are doing. If you break the code, just grab a new copy
# from the archive and copy it onto the MagTag USB drive.

############################### Initialize MagTag ######################################

magtag = MagTag()
buttons = magtag.peripherals.buttons
magtag.peripherals.speaker_disable = False      # turns on speaker amp
magtag.peripherals.neopixel_disable = False     # turns on the neopixels and the light sensor

# max neopixel brightness - everything is scaled by this number 0-1
magtag.peripherals.neopixels.brightness = .05

############################## Initialize SHT4x #######################################

#i2c = board.I2C()  # uses board.SCL and board.SDA
i2c = board.STEMMA_I2C()  # For using the built-in STEMMA QT connector on a microcontroller
sht = adafruit_sht4x.SHT4x(i2c)
print("Found SHT4x with serial number", hex(sht.serial_number))

sht.mode = adafruit_sht4x.Mode.NOHEAT_HIGHPRECISION
# Can also set the mode to enable heater
# sht.mode = adafruit_sht4x.Mode.LOWHEAT_100MS
print("Current mode is: ", adafruit_sht4x.Mode.string[sht.mode])

###################### Update the LED bargraph display ################################

def set_bargraph(relative_humidity):

    magtag.peripherals.neopixels.brightness = magtag.peripherals.light / 20000.0

    if (relative_humidity > RHL5):
        magtag.peripherals.neopixels[3] = RED
        magtag.peripherals.neopixels[2] = RED
        magtag.peripherals.neopixels[1] = RED
        magtag.peripherals.neopixels[0] = RED

    elif (relative_humidity > RHL4):
        magtag.peripherals.neopixels[3] = RED
        magtag.peripherals.neopixels[2] = RED
        magtag.peripherals.neopixels[1] = RED
        magtag.peripherals.neopixels[0] = YELLOW

    elif (relative_humidity > RHL3):
        magtag.peripherals.neopixels[3] = RED
        magtag.peripherals.neopixels[2] = RED
        magtag.peripherals.neopixels[1] = YELLOW
        magtag.peripherals.neopixels[0] = GREEN

    elif (relative_humidity > RHL2):
        magtag.peripherals.neopixels[3] = RED
        magtag.peripherals.neopixels[2] = YELLOW
        magtag.peripherals.neopixels[1] = GREEN
        magtag.peripherals.neopixels[0] = GREEN

    elif (relative_humidity > RHL1):  #10
        magtag.peripherals.neopixels[3] = YELLOW
        magtag.peripherals.neopixels[2] = GREEN
        magtag.peripherals.neopixels[1] = GREEN
        magtag.peripherals.neopixels[0] = GREEN

    else:
        magtag.peripherals.neopixels[3] = GREEN
        magtag.peripherals.neopixels[2] = GREEN
        magtag.peripherals.neopixels[1] = GREEN
        magtag.peripherals.neopixels[0] = GREEN


#################### Find max/min in data set for graph scaling #######################

def max_min():

    global maxt
    global mint
    global maxh
    global minh
    global tscale
    global hscale

    # find max/min values

    maxt = mint = tempbuffer[2]
    maxh = minh = humbuffer[2]

    for gvs in range (2, 295):
        if (tempbuffer[gvs] > maxt):
            maxt = tempbuffer[gvs]
        if (tempbuffer[gvs] < mint):
            mint = tempbuffer[gvs]
        if (humbuffer[gvs] > maxh):
            maxh = humbuffer[gvs]
        if (humbuffer[gvs] < minh):
            minh = humbuffer[gvs]

    tscale = 110.0 / (maxt - mint)
    hscale = 110.0 / (maxh - minh)

#################### Draw graph #######################

def draw_graph():

    global maxh
    global minh
    global maxt
    global mint

    # use built in display (PyPortal, PyGamer, PyBadge, CLUE, etc.)
    # see guide for setting up external displays (TFT / OLED breakouts, RGB matrices, etc.)
    # https://learn.adafruit.com/circuitpython-display-support-using-displayio/display-and-display-bus
    display = board.DISPLAY

    #print(magtag.display.time_to_refresh)
    while (magtag.display.time_to_refresh > 0.0):   # let the last refresh finish or throws error and stops
        time.sleep(.1)
        #print ("Wait")

    # Make the display context
    splash = displayio.Group()
    display.root_group = splash

    # Make a background color fill white/0xFFFFFF
    # 2.9" grayscale display with 296x128 pixels. Each pixel can be white, light gray, dark gray, or black.
    color_bitmap = displayio.Bitmap(display.width, display.height, 1)
    color_palette = displayio.Palette(1)
    color_palette[0] = 0xFFFFFF
    bg_sprite = displayio.TileGrid(color_bitmap, x=0, y=0, pixel_shader=color_palette)
    splash.append(bg_sprite)

    # Draw vertical grid lines every 30 pixels
    for x in range(295, 0, -49):
        vertical_line = Line(x, 2, x, 125, color=0xBBBBBB)
        splash.append(vertical_line)

    # Draw horizontal grid lines every 26 pixels
    for y in range(127, 0, -32):
        horizontal_line = Line(2, y, 293, y, color=0xBBBBBB)
        splash.append(horizontal_line)

    # Draw the temperature line if selected
    if DrawTemp:
        for segments in range (2, 294):
            splash.append(Line(segments, int(scale_temp[segments]), segments + 1, int(scale_temp[segments + 1]), 0xAAAAAA))

    # Draw the humidity line (Always displayed)
    for segments in range (2, 294):
        splash.append(Line(segments, int(scale_hum[segments]), segments + 1, int(scale_hum[segments + 1]), 0x444444))

    if (DrawLabels):
        TEXT = str(int(maxh * 10) / 10.0) + " %"
        text_area = label.Label(
            terminalio.FONT,
            text=TEXT,
            color=0xFFFFFF,
            background_color=0x444444,
            padding_top=2,
            padding_bottom=3,
            padding_right=4,
            padding_left=4,
        )

        text_area.x = 6
        text_area.y = 10
        splash.append(text_area)

        TEXT = str(int(minh * 10) / 10.0) + " %"
        text_area = label.Label(
            terminalio.FONT,
            text=TEXT,
            color=0xFFFFFF,
            background_color=0x444444,
            padding_top=3,
            padding_bottom=2,
            padding_right=4,
            padding_left=4,
        )

        text_area.x = 6
        text_area.y = 118
        splash.append(text_area)

    # Note, local and global variables
    if (DrawLabels & DrawTemp):
        if (Celsius):
            TEXT = str(int(maxt * 10) / 10.0) + " C"
        else:
            mxt = ((maxt * 9) / 5) + 32.0
            TEXT = str(int(mxt * 10) / 10.0) + " F"

        text_area = label.Label(
            terminalio.FONT,
            text=TEXT,
            color=0xFFFFFF,
            background_color=0xAAAAAA,
            padding_top=2,
            padding_bottom=3,
            padding_right=4,
            padding_left=4,
        )

        text_area.x = 254
        text_area.y = 10
        splash.append(text_area)

        if (Celsius):
            TEXT = str(int(mint * 10) / 10.0) + " C"
        else:
            mnt = ((mint * 9) / 5) + 32.0
            TEXT = str(int(mnt * 10) / 10.0) + " F"

        text_area = label.Label(
            terminalio.FONT,
            text=TEXT,
            color=0xFFFFFF,
            background_color=0xAAAAAA,
            padding_top=3,
            padding_bottom=2,
            padding_right=4,
            padding_left=4,
        )

        text_area.x = 254
        text_area.y = 118
        splash.append(text_area)

    border = Rect(0, 0, 296, 128, outline=0x0, stroke=2)
    splash.append(border)

    display.refresh()
    #print(magtag.display.time_to_refresh)

################################ Main Setup ########################################

temperature, relative_humidity = sht.measurements
mint = temperature
maxt = temperature
minh = relative_humidity
maxh = relative_humidity
tscale = 1.0
hscale = 1.0
alarm = False

print ()
print ("RH (%), Temp (C)")

# just collecting real data to fill the arrays so it will be near ambient
# and real data collection can continue fairly seamlessly
chase = 3
for gvs in range (2, 295):
    temperature, relative_humidity = sht.measurements
    tempbuffer[gvs] = temperature
    humbuffer[gvs] = relative_humidity

    print (relative_humidity, temperature)

    magtag.peripherals.neopixels[chase] = DARK
    chase = chase - 1
    if (chase < 0):
        chase = 3
    magtag.peripherals.neopixels[chase] = PURPLE

    time.sleep(0.04)

magtag.peripherals.neopixels[chase] = DARK

max_min()				# find new max and min

#scale the data for display
for gvs in range (2, 295):
    scale_temp[gvs] = 120.0 - ((tempbuffer[gvs] - mint) * tscale)
    scale_hum[gvs] = 120.0 - ((humbuffer[gvs] - minh) * hscale)

draw_graph()

# Calculate seconds between data points
intervalseconds = (HoursToDisplay * 60 * 60) / 293      # 293 is the number of graph points
                                                        # with the border around the graph

print ()
print ("Ave RH (%), Max RH (%), Temp (C)")

#################################### Main Loop ###########################################

while True:     # Main Loop - gather data, update the max/min values, watch for buttons

    start_time = time.time()
    #print ("starting new collection period")

    sxmaxh = 0.0

    while ((time.time() - start_time) < intervalseconds): # for the time between data points

        sumtemps = 0.0
        sumhums = 0.0
        dothedraw = False

        # Note - RH can be reported as negative or >100 under certain conditions near 0 and 100%
        # See datasheet for Sensiron SHT4x for details. 0.0 and 100.0 tests likely aren't needed
        # because we likely won't be that close to either limit where clipping is necessary.

        for i in range(0, 10):
            temperature, relative_humidity = sht.measurements

            if (relative_humidity < 0.0):
                relative_humidity = 0.0
            if (relative_humidity > 100.0):
                relative_humidity = 100.0

            set_bargraph(relative_humidity)	# set bargraph

            # gather sums for averages
            sumtemps = sumtemps + temperature
            sumhums = sumhums + relative_humidity

            if (Alarm):
                if (relative_humidity >= AlarmLevel):
                    magtag.peripherals.play_tone (550, 0.2)
                    #print ("Alarm tone")
                    #time.sleep(0.2)

            if (dothedraw == False):

                for i, b in enumerate(magtag.peripherals.buttons):
                    if not b.value:
                        #print(f"Button {chr(ord('A') + i)} pressed")
                        #print (i)

                        if (i == 0):
                            DrawTemp = not DrawTemp
                            dothedraw = True
                            if ButtonSound:
                                magtag.peripherals.play_tone (600, 0.2)
                                #print ("TGraph")
                                #time.sleep(0.2)
                        elif (i == 1):
                            Celsius = not Celsius
                            dothedraw = True
                            if ButtonSound:
                                magtag.peripherals.play_tone (600, 0.2)
                                #print ("Units")
                                #time.sleep(0.2)
                        elif (i == 2):
                            DrawLabels = not DrawLabels
                            dothedraw = True
                            if ButtonSound:
                                magtag.peripherals.play_tone (600, 0.2)
                                #print ("Labels")
                                #time.sleep(0.2)
                        elif (i == 3):
                            Alarm = not Alarm
                            if Alarm:
                                magtag.peripherals.play_tone (200, 0.2) # "do-dee"  (trill up - turn on alarm)
                                magtag.peripherals.play_tone (300, 0.2)
                                #print ("Trill Up")
                                #time.sleep(0.4)
                            else:
                                magtag.peripherals.play_tone (300, 0.2) # "dee-do"  (trill down - turn off alarm)
                                magtag.peripherals.play_tone (200, 0.2)
                                #print ("Trill Down")
                                #time.sleep(0.4)

                        # Hold up until they release the button
                        while magtag.peripherals.any_button_pressed:
                            time.sleep(0.1)

            if dothedraw:
                draw_graph()
                dothedraw = False

            time.sleep(.1)

        avetemp = sumtemps / 10    # each time through, ~1 second, it signal averages 10 samples
        avehum = sumhums / 10

        # This is a bit tricky. We want to catch door openings and such that are too fast to be captured
        # at the data collection times. We are interested more in spikes rather than dips in humidity.
        # So what we do is use the max humidity value during each data period as the humidity value.
        # That way we capture the transients at the expense of jitter in the time between recorded data
        # points.
        if (avehum > sxmaxh):
            sxmaxh = avehum

    for gvs in range (2, 294):
	   # shift everyone down to make room for new measurement
	   tempbuffer[gvs] = tempbuffer[gvs + 1]
	   humbuffer[gvs] = humbuffer[gvs + 1]

    tempbuffer[294] = avetemp		# save the new temperature measurement

    if UseMax:
        humbuffer[294] = sxmaxh         # use the max value seen during the sampling period (time jitter)
    else:
        humbuffer[294] = avehum         # use the last value captured during the sampling period

    max_min()				# find new max and min

    #scale the data for display
    for gvs in range (2, 294):
        scale_temp[gvs] = 120.0 - ((tempbuffer[gvs] - mint) * tscale)
        scale_hum[gvs] = 120.0 - ((humbuffer[gvs] - minh) * hscale)

    print (avehum,sxmaxh,avetemp)     # put average humidity during sample period, max humidity,
                                        # and average temperature on the USB port for logging
    draw_graph()

    #print (DrawTemp, Celsius, DrawLabels, avetemp, avehum, sxmaxh)
